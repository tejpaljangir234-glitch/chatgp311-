# ChatGP 311 Backend

A small Node.js + Express backend for a Gemini-powered chat app.

## Deploy on Render

1. Upload `package.json` and `server.js` to a new GitHub repository.
2. In Render, choose **New → Web Service** and connect that repository.
3. Use:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
4. In Render → your service → **Environment**, add:
   - Key: `GEMINI_API_KEY`
   - Value: your newly created Gemini API key
5. Save and deploy. Do not put the API key in HTML or GitHub.
6. When deploy succeeds, test `https://YOUR-SERVICE.onrender.com/`.
   It should return JSON with status `ok`.

## Chat endpoint

POST `https://YOUR-SERVICE.onrender.com/api/chat`

JSON body:
```json
{"message":"नमस्ते, आप कौन हैं?"}
```

Response:
```json
{"reply":"..."}
```

The model name is set to `gemini-3.8-flash`. If that model is unavailable for your API project, change it in `server.js` to a model shown as available in Google AI Studio.

Keep your API key private. If a key was exposed in a screenshot or public place, revoke it and create a new one.
