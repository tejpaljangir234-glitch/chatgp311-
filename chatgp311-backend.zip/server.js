import express from "express";
import cors from "cors";
import { GoogleGenAI } from "@google/genai";

const app = express();
const PORT = process.env.PORT || 10000;

app.use(cors());
app.use(express.json({ limit: "1mb" }));

app.get("/", (_req, res) => {
  res.json({ status: "ok", app: "ChatGP 311 backend" });
});

app.post("/api/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string"
      ? req.body.message.trim()
      : "";

    if (!message) {
      return res.status(400).json({ error: "Please enter a message." });
    }
    if (message.length > 10000) {
      return res.status(413).json({ error: "Message is too long (maximum 10,000 characters)." });
    }
    if (!process.env.GEMINI_API_KEY) {
      return res.status(500).json({ error: "Server is missing GEMINI_API_KEY." });
    }

    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    const result = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: message
    });

    return res.json({ reply: result.text || "I couldn't generate a response. Please try again." });
  } catch (error) {
    console.error("Gemini request failed:", error?.message || error);
    return res.status(500).json({
      error: "AI request failed. Check the server logs and Gemini API configuration."
    });
  }
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`ChatGP 311 backend listening on port ${PORT}`);
});
